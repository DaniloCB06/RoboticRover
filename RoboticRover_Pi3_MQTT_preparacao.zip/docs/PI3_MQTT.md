# RoboticRover — Preparação da Raspberry Pi 3 ↔ estação-base

Este pacote é um **complemento** para o repositório real. Não temos acesso aos
arquivos atuais do VS Code nem à versão mais recente da dashboard; **faça merge**, não
substitua flows ou arquivos existentes às cegas.

## O que está pronto

- Cliente MQTT 5/Paho em Python (mesmos tópicos do Node-RED já compartilhado).
- Estado inicial `SEGURO_ESPERA` e validação de comandos para simulação.
- Heartbeat, ACK/NACK, bloqueio de comando vencido, duplicado ou retained.
- MQTT Last Will + status retained; status do Linux com `simulated:false`.
- Telemetria artificial **desabilitada por padrão** (pode habilitar para demonstrar).
- Testes unitários que não exigem a Raspberry Pi nem o broker.

**Ainda não:** controle real do Arduino, sensores reais, visão computacional,
streaming de câmera, endpoints do professor, instalação e configuração do sistema.

## Testar agora no notebook

Abra um terminal em `apps/rover` no repositório:

```bash
python3 -m venv .venv
source .venv/bin/activate  # Linux/macOS; no PowerShell: .\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
cp .env.example .env  # Ajuste MQTT_HOST para IP do notebook/host do Mosquitto
python -m unittest discover -s tests -v
python -m roboticrover_pi3
```

No Windows, copie manualmente `.env.example` como `.env` se não usar shell Unix.

Aponte o broker para o host do notebook onde Mosquitto já está sendo executado;
no Docker é necessário publicar a porta 1883 e habilitar a escuta na rede com
autenticação adequada. Não configure dois brokers sem necessidade.

## Quando a Raspberry Pi 3 estiver pronta

1. Instale Raspberry Pi OS, configure SSH e conecte Pi/notebook à mesma rede.
2. Clone ou sincronize o **mesmo repositório** na Pi (não copie o monorepo inteiro se não for necessário).
3. Abra `apps/rover`, crie `.venv` e instale `requirements.txt`.
4. Crie `.env` a partir de `.env.example`, com IP/hostname **da estação-base** em `MQTT_HOST`.
5. Rode `python -m roboticrover_pi3`.
6. No Node-RED, verifique `rover/status`: `simulated:false`, `online:true` e hostname da Pi.
7. Clique `BUSCA` e observe em `rover/cmd/ack` se houve aceitação ou rejeição.
8. Clique `PARAR` e confirme `SEGURO_ESPERA`; não haverá movimento de motor.

**Teste de conexão:** antes, confirme que notebook e Pi se enxergam e que
firewall/Wi-Fi não isolam clientes. `MQTT_HOST` na Pi **não é localhost**
se o broker estiver rodando no notebook.

## Node-RED (ajuste não destrutivo)

No fluxo original enviado, `Verificar envelope e tópico` exigia `p.simulated === true`.
Atualize a condição para exigir um booleano:

```javascript
// antes: p.simulated !== true
// depois: typeof p.simulated !== "boolean"
```

Isso permite status físico da Pi e telemetria simulada sem enfraquecer o restante
da validação. Arquivo de referência em
`apps/station/node-red/flows.original_com_ajuste_pi3.json` (baseado no
`flows.json` enviado **anteriormente**): **NÃO o importe como nova aba sem revisar,
pois poderá duplicar os fluxos da dashboard que você já construiu.**

O Node-RED original usa `global.get("crypto")`; preserve a configuração existente
no `settings.js` e as variáveis `MQTT_HOST`, `MQTT_PORT`, `STATION_CLIENT_ID` e
`STATION_SOURCE`. O botão PARAR que vocês criaram chega ao Rover como comando
manual `PARAR` e é aceito em qualquer estado de simulação.

## Autenticação e segurança

Em rede compartilhada, proteja o Mosquitto com autenticação e firewall;
`1883` sem TLS não é recomendado pela internet. Nunca faça commit de `.env` ou
senhas. `PARAR` via MQTT é apenas uma solicitação de software. No Rover real,
a parada da tração exigirá watchdog independente do Arduino, intertravamento
elétrico e parada de emergência física.

## Limitadores e integração futura

- Revisar o contrato de dados reais de cada sensor quando o hardware for identificado.
- Integrar Arduino Mega por USB serial em módulo próprio sem misturar com o MQTT.
- O timer de heartbeat é lógico e **não garante parada elétrica**.
- Se já houver outro simulador do Rover publicando nos mesmos tópicos, pare-o
  durante o teste físico para evitar estados/telemetrias conflitantes.
- Este serviço não deve coexistir usando o mesmo `MQTT_CLIENT_ID` que outra instância
  do Rover, pois uma derrubará a conexão da outra.
