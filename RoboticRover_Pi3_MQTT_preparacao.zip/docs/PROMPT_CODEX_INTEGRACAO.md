# Prompt curto para o Codex — integração sem sobrescrever repositório

Estou desenvolvendo o monorepo RoboticRover. MQTT Mosquitto e a dashboard Node-RED já
funcionam. Tenho um pacote de preparação da Raspberry Pi 3 com as pastas
`apps/rover`, `shared/contracts`, `apps/station/node-red` e `docs`.

**Tarefa:** inspecionar o repositório atual e incorporar somente o que estiver faltando
nesse pacote, sem sobrescrever a dashboard, os fluxos Node-RED atuais ou o cliente
MQTT que já exista. Adapte os caminhos à organização real do repositório.

Priorize o teste Pi 3 ↔ estação-base: cliente Python Paho MQTT 5, `.env` sem
credenciais versionadas, tópicos já existentes, LWT, status real com
`simulated:false`, recebimento de comandos, UUID, TTL, heartbeat e ACKs de
**simulação sem acionamento físico**. Não conecte motores nem adicione dependência
do Arduino nesta etapa.

O `flows.json` de referência tem 26 nós e a função de validação exige
`p.simulated !== true`; na dashboard atual, localize a validação equivalente e
ajuste para `typeof p.simulated !== "boolean"`, preservando a verificação dos
demais campos. Não importe o flow de referência integralmente se a dashboard
já mudou. Mantenha o estado seguro e não aceite comandos retained.

Execute testes unitários, revisão de compatibilidade Python da Raspberry Pi 3,
validação do JSON, e informe quais testes puderam ou não ser executados sem o
hardware e sem acesso ao broker. Atualize o README com instruções para rodar
o código no notebook e, posteriormente, na Raspberry Pi 3 real.
